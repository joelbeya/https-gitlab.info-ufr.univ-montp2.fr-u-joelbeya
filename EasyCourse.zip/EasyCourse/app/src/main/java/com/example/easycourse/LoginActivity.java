package com.example.easycourse;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.easycourse.model.User;
import com.example.easycourse.network.EasyCourseAPI;
import com.example.easycourse.network.RetrofitClient;
import com.google.android.material.textfield.TextInputLayout;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Retrofit;

import static com.example.easycourse.utils.Validation.validateEmail;
import static com.example.easycourse.utils.Validation.validateFields;

public class LoginActivity extends Activity {

    CompositeDisposable compositeDisposable =  new CompositeDisposable();
    EasyCourseAPI easyCourseAPI;

    private EditText mEtEmail;
    private EditText mEtPassword;
    private Button mBtLogin;
    private TextInputLayout mTiEmail;
    private TextInputLayout mTiPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Init service
        Retrofit retrofitClient = RetrofitClient.getInstance();
        easyCourseAPI = retrofitClient.create(EasyCourseAPI.class);

        initViews();

        mBtLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login(v);
            }
        });
    }

    @Override
    protected void onStop() {
        compositeDisposable.clear();
        super.onStop();
    }

    private void initViews() {
        mEtEmail = findViewById(R.id.et_email);
        mEtPassword = findViewById(R.id.et_password);
        mBtLogin = findViewById(R.id.btn_login);
        mTiEmail= findViewById(R.id.ti_email);
        mTiPassword = findViewById(R.id.ti_password);
    }

    public void launchSignupActivity(View view) {
        Intent intent = new Intent(this, SignupActivity.class);
        startActivity(intent);
    }

    public void login(View view) {
        String email = mEtEmail.getText().toString();
        String password = mEtPassword.getText().toString();

        int err = 0;

        if (!validateEmail(email)) {
            err++;
            mTiEmail.setError("Email should be valid !");
        }

        if (!validateFields(password)) {
            err++;
            mTiPassword.setError("Password should not be empty !");
        }


        if (err == 0) {
            compositeDisposable.add(easyCourseAPI.login(email, password)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<String>() {
                    @Override
                    public void accept(String userResponse) throws Exception {
                        Toast.makeText(
                                LoginActivity.this, "" + userResponse, Toast.LENGTH_SHORT
                        ).show();
                    }
                }));
        }
    }
}
