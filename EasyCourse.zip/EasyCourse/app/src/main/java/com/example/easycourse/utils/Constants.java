package com.example.easycourse.utils;

public class Constants {
    public static final String BASE_URL = "https://beb3f002.ngrok.io/";
//    public static final String TOKEN = "token";
//    public static final String EMAIL = "email";
}
